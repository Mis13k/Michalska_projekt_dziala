﻿namespace ECommerceShoppingCartAppASPNET7.Models
{
    public class Product
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
        public string Photo { get; set; }
        public int Quantity { get; set; }

    }
}
