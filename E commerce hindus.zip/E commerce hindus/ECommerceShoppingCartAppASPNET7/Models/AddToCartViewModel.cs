﻿namespace ECommerceShoppingCartAppASPNET7.Models
{
    public class AddToCartViewModel
    {
        public string ProductId { get; set; }
        public int Quantity { get; set; }
    }
}
